import Popup from './Popup.js';

const popupDeleteSelectors = {

}

export default class PopupDelete extends Popup {
  constructor(popupSelector, submitHandlerDelete) {
    super(popupSelector);
    this._submitHandlerDelete = submitHandlerDelete;
    this._form = this._popup.querySelector('form');
  }

  setEventListeners () {
    super.setEventListeners();
    this._popup.addEventListener('submit', (event) => {
      event.preventDefault();
      this._submitHandlerDelete(event);
      this.close();
    });
  }

  open = _ => super.open();
}

